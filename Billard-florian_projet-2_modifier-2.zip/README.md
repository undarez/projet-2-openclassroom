Intégration frontale statique réactive
HTML, CSS
Projet de réservation HTML CSS
Ce projet concerne la mise en œuvre de la conception Web, avec uniquement du HTML et du CSS de base.
Fonctionnalités
La recherche de champ de saisie peut être modifiée par l'utilisateur, cependant, à ce stade, le bouton de recherche ne sera pas fonctionnel.
Chaque carte d'hébergement ou d'activité doit être cliquable, mais les liens seront vides.
Les filtres ne seront pas fonctionnels pour cette version, cependant, ils doivent être changés d'apparence au survol.
Dans le menu, les liens « Hébergement » et « Activités » sont des ancres qui doivent mener aux sections appropriées de la page.
Contraintes techniques
Deux modèles fournis : desktop et mobile. Le site doit également être adapté aux tablettes ; l'adaptation est gratuite.
Aucune indication sur les tailles et les résolutions ; on part du modèle lui-même sans autre indication.
Utilisation des icônes de la bibliothèque Font Awesome.
Les couleurs à utiliser : le bleu #0065FC et sa version plus claire #DEEBFF, le gris pour le fond #F2F2F2.
La police principale est Raleway